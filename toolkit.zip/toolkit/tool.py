from flask import Flask, request, render_template
from flask.wrappers import Response
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import dataframe_image as dfi


import os

app = Flask(__name__,template_folder='template')
F = ""
details = ""
df = ""
@app.route("/", methods = ["GET","POST"])
def home():
    return render_template('home.html')


def data():
    if request.method =="POST":
        file = request.files["csvfile"]
        # print(file)
        if not os.path.isdir('static'):
            os.mkdir('static')
        filepath = os.path.join('static', file.filename)
        file.save(filepath)
    File = file.filename
    global F 
    # F = file.filename
    # print(x)
    F = pd.read_csv("static/"+File,header=None)
    name = request.form["person"]
    algo = request.form["algorithm"]
    return F,name,algo

@app.route("/data", methods = ["GET","POST"])
def header_checking():
    dataset,name,algo = data()
    Response = dataset.columns
    if name == "Beginner" and algo=="linear":
        return render_template("beginner.html", data = Response, l = len(Response) )
    elif name == "Expert" and algo=="linear":
#         fit = request.form.get["intercept"]
        return render_template("expert.html", data = Response)

@app.route("/lbresponse", methods = ["GET","POST"])
def lbresponse():
    #  preprocesing
    # df1 = F.replace(' ',np.nan)
    df2 = F.dropna()
    df2.drop_duplicates()
    global df
    df = df2
    global details
    details = df.describe()
    # print(details)
    imagedesc = os.path.join('static','image'+'.png')
    dfi.export(details,imagedesc)
    if request.method == "POST":
        settype=list(df.columns)
        y = request.form.get("feature")
        if y.isnumeric():
            y = int(y)
        Y=df[y].values
        X=df.drop(columns=y)
        X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3)
        x_train = X_train
        X_train = np.array(X_train)
        y_train = np.array(y_train)
        theta=np.zeros((len(settype),1))
        print(len(X_train))
        print(len(y_train))
        # ---------------------------------------------------------------------
        if(len(settype)==2):
            plt.scatter(X_train, y_train,c="blue")
            imageplot1 = os.path.join('static','exp&res'+'.png')
            plt.savefig(imageplot1)
            reg = LinearRegression().fit(X_train, y_train)
            score = reg.score(X_train, y_train)
            X_test = np.array(X_test)
            predict = reg.predict(X_test)
            # --------------------------------------------------------------------
            plt.scatter(X_test,y_test,color='gray')
            plt.plot(X_test,predict,color='red',linewidth=2)
            imageplot3 = os.path.join('static','line&actual&predcit'+'.png')
            plt.savefig(imageplot3)
            # -------------------------------------------------------------------------
            values=pd.DataFrame({'Actual':y_test.flatten(),'predicted':predict.flatten()})
            value1 = values.head(15)
            value1.plot(kind='bar',figsize=(16,10))
            plt.grid(which='major', linestyle='-',linewidth='0.5', color='green')
            plt.grid(which='minor', linestyle=':',linewidth='0.5', color='black')
            imageplot2 = os.path.join('static','actual&predcit'+'.png')
            plt.savefig(imageplot2)
            # -------------------------------------------------------------------------
            meansquareerror = np.mean((predict-y_test)**2)
            y22 = r2_score(y_test, predict)
            return render_template("feature.html", featuring = predict,l = len(settype),error = y22,tables=[value1.to_html(classes='data')],titles=value1.columns.values,image=imagedesc,image1=imageplot1,image2=imageplot2,image3=imageplot3,mnerror=meansquareerror)
        else:
            x = request.form.get("x_val")
            X_val = x_train[int(x)].values
            print(len(X_val))
            print(len(y_train))
            plt.scatter(X_val, y_train,c="blue")
            imageplot1 = os.path.join('static','exp&res'+'.png')
            plt.savefig(imageplot1)
            reg = LinearRegression().fit(X_train, y_train)
            score = reg.score(X_train, y_train)
            X_test = np.array(X_test)
            predict = reg.predict(X_test)
            # ---------------------------------------------------------
            values=pd.DataFrame({'Actual':y_test.flatten(),'predicted':predict.flatten()})
            value1 = values.head(15)
            value1.plot(kind='bar',figsize=(16,10))
            plt.grid(which='major', linestyle='-',linewidth='0.5', color='green')
            plt.grid(which='minor', linestyle=':',linewidth='0.5', color='black')
            imageplot2 = os.path.join('static','actual&predcit'+'.png')
            plt.savefig(imageplot2)
            # ----------------------------------------------------------
            meansquareerror = np.mean((predict-y_test)**2)
            y22 = r2_score(y_test, predict)
            return render_template("feature.html", featuring = predict,l = len(settype),error = y22,tables=[value1.to_html(classes='data')],titles=value1.columns.values,image=imagedesc,image1=imageplot1,image2=imageplot2,mnerror=meansquareerror)

            
            
            

@app.route("/leresponse", methods = ["GET","POST"])
def leresponse():
    df2 = F.dropna()
    df2.drop_duplicates()
    global df
    df = df2
    global details
    details = df.describe()
    imagedesc = os.path.join('static','image'+'.png')
    dfi.export(details,imagedesc)
    if request.method == "POST":
        settype=list(df.columns)
        y = request.form.get("feature")
        if y.isnumeric():
            y = int(y)
        Y=df[y].values
        X=df.drop(columns=y)
        t = request.form.get("split")
        t = int(t)/100
        X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=t)
        x_train = X_train
        x = request.form.get("x_val")
        X_val = x_train[int(x)].values
        X_train = np.array(X_train)
        y_train = np.array(y_train)
        normalize = False
        fit_intercept = request.form.get("Fit_intercept")
        normalize = request.form.get("Normalize")
        copy_X = request.form.get("Copy_X")
        positive = request.form.get("Positive")
        model = LinearRegression(fit_intercept=fit_intercept, normalize= normalize, copy_X= copy_X,positive=positive,)
        model.fit(X_train,y_train)
        model.score(X_train,y_train)
        predict = model.predict(X_test)
        y22 = r2_score(y_test, predict)
        meansquareerror = np.mean((predict-y_test)**2)
        # ---------------------------------------------------------
        values=pd.DataFrame({'Actual':y_test.flatten(),'predicted':predict.flatten()})
        value1 = values.head(15)
        print(value1)
        value1.plot(kind='bar',figsize=(16,10))
        plt.grid(which='major', linestyle='-',linewidth='0.5', color='green')
        plt.grid(which='minor', linestyle=':',linewidth='0.5', color='black')
        imageplot2 = os.path.join('static','actual&predcit'+'.png')
        plt.savefig(imageplot2)
        # ----------------------------------------------------------
    return render_template("feature.html", featuring = predict,error = y22,tables=[value1.to_html(classes='data')],titles=value1.columns.values ,image2=imageplot2,mnerror=meansquareerror)
        
if __name__ == "__main__":
    app.run(debug=True) 